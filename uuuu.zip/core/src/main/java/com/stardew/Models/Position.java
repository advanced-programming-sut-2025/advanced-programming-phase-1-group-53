package com.stardew.Models;

public class Position {
    private int x;
    private int y;
    private int width;
    private int height;

    public Position(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public void changeX(int input) {
        this.x += input;
    }

    public void changeY(int input) {
        this.y += input;
    }

    public boolean isHere(int x, int y){
        if(this.x == x && this.y == y)
            return true;
        return false;
    }
}
