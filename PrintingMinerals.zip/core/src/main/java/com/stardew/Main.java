package com.stardew;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.graphics.glutils.ShaderProgram;
import com.badlogic.gdx.utils.ScreenUtils;
import com.stardew.Models.Game.GameAssetManager;
import com.stardew.Models.GameMap;
import com.stardew.Views.AppView;
import com.stardew.Views.GameMenu;
import com.stardew.Views.Tab;
import com.stardew.Views.TabMenus.InventoryMenu;

/** {@link com.badlogic.gdx.ApplicationListener} implementation shared by all platforms. */
public class Main extends Game {
    public static Main main = new Main();
    private SpriteBatch batch;
    public static Sprite sprite;


    @Override
    public void create() {
        try{
            setScreen(GameMenu.getInstance());
            batch = new SpriteBatch();
            //sprite = new Sprite(new Texture("Foragings/Trees/Orange_Stage_5.png"));
        }
        catch (Exception e){
            e.printStackTrace();
        }

    }

    @Override
    public void render() {
        try{
//            batch.begin();
//            sprite.draw(batch);
//            batch.end();
            super.render();
        }
        catch (Exception e){
                e.printStackTrace();
        }
    }

    @Override
    public void dispose() {
        batch.dispose();
        sprite.getTexture().dispose();
    }
}
