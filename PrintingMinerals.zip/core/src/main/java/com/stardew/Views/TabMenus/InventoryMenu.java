package com.stardew.Views.TabMenus;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.stardew.Main;
import com.stardew.Models.Game.App;
import com.stardew.Models.Game.GameAssetManager;
import com.stardew.Views.GameMenu;
import com.stardew.Views.Tab;

import java.awt.*;

public class InventoryMenu extends Tab {
    private static final float SCREEN_WIDTH = Gdx.graphics.getWidth();
    private static final float SCREEN_HEIGHT = Gdx.graphics.getHeight();
    private static int FIRST_LEVEL_MARGIN = 80;
    private static final int SECOND_LEVEL_MARGIN = 135;
    private static final int START_X =(int) SCREEN_WIDTH/4;
    private static final int START_Y =(int) SCREEN_HEIGHT/3;
    private static final int ROWS_WIDTH =400;
    private static final int ROWS_HEIGHT = 130;
    private static final int WIDGET_HEIGHT =50;
    private static final int WIDGET_WIDTH = 50;
    private static final int FARMER_LEVEL_WIDTH = 90;
    private static final int FARMER_LEVEL_HEIGHT = 80;
    private static InventoryMenu inventoryMenu = null;
    private Sprite s = new Sprite(GameAssetManager.getInventorySprites()[0]);
    private static Sprite[] sprites = new Sprite[]{
        new Sprite(GameAssetManager.getInventorySprites()[0]),
        new Sprite(GameAssetManager.getInventorySprites()[1]),
        new Sprite(GameAssetManager.getInventorySprites()[2]),
        new Sprite(GameAssetManager.getInventorySprites()[3]),
        new Sprite(GameAssetManager.getInventorySprites()[4]),
        new Sprite(GameAssetManager.getInventorySprites()[5])
    };
    private static int[] SpriteX = new int[]{START_X,START_X + WIDGET_WIDTH, START_X+2*WIDGET_WIDTH,START_X+3*WIDGET_WIDTH,START_X,START_X,};
    private static int[] SpriteY = new int[]{ START_Y+FIRST_LEVEL_MARGIN+SECOND_LEVEL_MARGIN-5,START_Y+FIRST_LEVEL_MARGIN
        +SECOND_LEVEL_MARGIN,START_Y+FIRST_LEVEL_MARGIN+SECOND_LEVEL_MARGIN,START_Y+FIRST_LEVEL_MARGIN+SECOND_LEVEL_MARGIN,
        START_Y+FIRST_LEVEL_MARGIN,START_Y
    };
    private static int[] SpriteWidth = new int[]{ WIDGET_WIDTH, WIDGET_WIDTH, WIDGET_WIDTH, WIDGET_WIDTH,
        ROWS_WIDTH,FARMER_LEVEL_WIDTH};
    private static int[] SPriteHeight = new int[]{WIDGET_HEIGHT,WIDGET_HEIGHT,WIDGET_HEIGHT,WIDGET_HEIGHT,
        ROWS_HEIGHT, FARMER_LEVEL_HEIGHT};

    public static InventoryMenu getInstance(){
        if(inventoryMenu == null)
            inventoryMenu = new InventoryMenu();
        return inventoryMenu;
    }

    @Override
    public void show(){
        super.show();
    }


    @Override
    public void render(float delta){
        super.render(delta);
        if (!batch.isDrawing()) {
            batch.begin();
        }
        for(int i = 0; i < sprites.length-1; i++){
            Sprite s = sprites[i];
            s.setSize( SpriteWidth[i], SPriteHeight[i]);
            s.setPosition(SpriteX[i], SpriteY[i]);
            if(i == 4) {
                s.draw(batch);
            }
            else
                s.draw(batch);
        }

        if (batch.isDrawing()) {
            batch.end();
        }
    }

    @Override
    public boolean keyDown(int keycode) {
        System.out.println(keycode);
        if(keycode == Input.Keys.ESCAPE){
            Main.main.setScreen(GameMenu.getInstance());
            return true;
        }
        return false;
    }
}
