package com.stardew.Models;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.stardew.Enums.TileKind;
import com.stardew.Models.Game.App;
import com.stardew.Models.Game.GameAssetManager;
import com.stardew.Models.Items.Item;

public class Tile {
    private Sprite sprite = new Sprite();
    private final Position position;
    private TileKind tileKind;
    private Item item = null;

    public Tile(Position position, TileKind tileKind) {
        this.position = position;
        this.tileKind = tileKind;
        if(tileKind.equals(TileKind.grass))
            sprite = new Sprite(GameAssetManager.getTilesTextures()[0],GameMap.getTilePrintSize() ,GameMap.getTilePrintSize());
        else if(tileKind.equals(TileKind.wall))
            sprite = new Sprite(GameAssetManager.getTilesTextures()[1],GameMap.getTilePrintSize() ,GameMap.getTilePrintSize());
        else if(tileKind.equals(TileKind.asphalt))
            sprite = new Sprite(GameAssetManager.getTilesTextures()[2],GameMap.getTilePrintSize() ,GameMap.getTilePrintSize());
        else if(tileKind.equals(TileKind.structure))
            sprite = new Sprite(GameAssetManager.getTilesTextures()[0],GameMap.getTilePrintSize() ,GameMap.getTilePrintSize());
        else if(tileKind.equals(TileKind.shop))
            sprite = new Sprite(GameAssetManager.getTilesTextures()[2],GameMap.getTilePrintSize() ,GameMap.getTilePrintSize());
        else if(tileKind.equals(TileKind.NPC))
            sprite = new Sprite(GameAssetManager.getTilesTextures()[1],GameMap.getTilePrintSize() ,GameMap.getTilePrintSize());

        else if(tileKind.equals(TileKind.mine))
            sprite = new Sprite(GameAssetManager.getTilesTextures()[3],GameMap.getTilePrintSize() ,GameMap.getTilePrintSize());
        else
            sprite = new Sprite(GameAssetManager.getTilesTextures()[0],GameMap.getTilePrintSize() ,GameMap.getTilePrintSize());
    }

    public Sprite getSprite() {
        return sprite;
    }

    public void setSprite(Texture texture){
        sprite.setTexture(texture);
    }

    public Item getItem() {
        return item;
    }

    public void setItem(Item item) {
        this.item = item;
    }

    public void pickItem(){
        if(item == null){
            System.out.println("jsdbjhbs");
            return;
        }
        App.getGame().getCurrentPlayer().backpack.addItem(App.getGame().getItemByItemType(item.getItemType()));
        item = null;
    }

    public Position getPosition() {
        return position;
    }

    public TileKind getTileKind() {
        return tileKind;
    }

    public void setTileKind(TileKind tileKind) {
        this.tileKind = tileKind;
    }
}
