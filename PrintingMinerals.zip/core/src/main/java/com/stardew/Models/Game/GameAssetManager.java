package com.stardew.Models.Game;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.ui.TextTooltip;
import com.stardew.Enums.ItemType;
import org.w3c.dom.Text;

import java.util.HashMap;

public class GameAssetManager {
    private final static Texture[] BUILDINGS_IN_DIFFERENT_SEASONS = new Texture[]{
        new Texture("Buildings/Pelican Town Spring.png"),
        new Texture("Buildings/Pelican Town Summer.png"),
        new Texture("Buildings/Pelican Town Fall.png"),
        new Texture("Buildings/Pelican Town Winter.png")
    };
    private final static Texture FULL_ENERGY_SPRITE = new Texture("energy_bar.png");
    private final static Texture EMPTY_ENERGY_BAR_SPRITE = new Texture("empty_energy.png");
    private final static Texture LAKE_TEXTURE = new Texture("Buildings/lakeSprite.png");
    private final static Texture GREENHOUSE_SPRITE = new Texture("Buildings/greenhouse.png");
    private final static Texture[] TILES_TEXTURES = new Texture[]{new Texture("Tiles/Flooring_44.png"),
    new Texture("Tiles/Flooring_55.png"), new Texture("Tiles/Flooring_30.png"),
    new Texture("Tiles/Flooring_52.png")};
    private final static Texture[] INVENTORY_SPRITES = new Texture[]{
        new Texture("Menus/InventoryWidget.png"),new Texture("Menus/Social_Widget.png"),
        new Texture("Menus/Map_Widget.png"), new Texture("Menus/Skills_Widget.png"),
        new Texture("Menus/Inventory Rows.png"), new Texture("Menus/Level_Farmer.png")
    };
    private final static TextureRegion[] JOJA_MART_SPRITES = generateTextureRegion(0, 820, 250, 170);
    private final static TextureRegion[] PIERRE_SPRITES = generateTextureRegion(80,176,156,146);
    private final static TextureRegion[] STARDROP_SPRITES = generateTextureRegion(240, 176, 112, 146);
    private final static TextureRegion[] FISH_STORE_AND_HOUSE_SPRITES = generateTextureRegion(384, 640, 136,164);
    private final static TextureRegion[] BLACK_SMITH_SPRITES = generateTextureRegion(128*2,0,128,176);
    private final static TextureRegion[] CARPETNER_SPRITES = generateTextureRegion(0, 0, 128, 176);
    private final static TextureRegion[] MARNIE_RANCH_SPRITES = generateTextureRegion(128, 0, 128, 176);
    public final static Texture ALEX = new Texture("Sprites/Alex/alexSprites.png");
    private final static TextureRegion[][] ALEX_TEXTURES = new TextureRegion[4][3];
    private final static HashMap<ItemType, Texture> SEED_TEXTURES = new HashMap<>(){{
        put(ItemType.MapleSeed, new Texture("Foragings/Seeds/Maple_Seed.png"));
        put(ItemType.SummerSquashSeed, new Texture("Foragings/Seeds/Summer_Squash_Seeds.png"));
        put(ItemType.RhubarbSeed, new Texture("Foragings/Seeds/Rhubarb_Seeds.png"));
        put(ItemType.StrawberrySeed, new Texture("Foragings/Seeds/Strawberry_Seeds.png"));
        put(ItemType.PumpkinSeed, new Texture("Foragings/Seeds/Pumpkin_Seeds.png"));
        put(ItemType.RedCabbageSeed, new Texture("Foragings/Seeds/Red_Cabbage_Seeds.png"));
        put(ItemType.MixedSeed, new Texture("Foragings/Seeds/Mixed_Seeds.png"));
        put(ItemType.KaleSeed, new Texture("Foragings/Seeds/Kale_Seeds.png"));
        put(ItemType.CornSeed, new Texture("Foragings/Seeds/Corn_Seeds.png"));
        put(ItemType.PineCone, new Texture("Foragings/Seeds/Pineapple_Seeds.png"));
        put(ItemType.BroccoliSeed, new Texture("Foragings/Seeds/Broccoli_Seeds.png"));
        put(ItemType.CauliFlowerSeed, new Texture("Foragings/Seeds/Cauliflower_Seeds.png"));
        put(ItemType.BokChoySeed, new Texture("Foragings/Seeds/Bok_Choy_Seeds.png"));
        put(ItemType.ArtichokeSeed, new Texture("Foragings/Seeds/Artichoke_Seeds.png"));
        put(ItemType.MysticTreeSeed, new Texture("Foragings/Seeds/Mystic_Tree_Seed.png"));
        put(ItemType.WheatSeed, new Texture("Foragings/Seeds/Wheat_Seeds.png"));
        put(ItemType.SunflowerSeed, new Texture("Foragings/Seeds/Sunflower_Seeds.png"));
        put(ItemType.SpangleSeed, new Texture("Foragings/Seeds/Spangle_Seeds.png"));
        put(ItemType.PotatoSeed, new Texture("Foragings/Seeds/Potato_Seeds.png"));
        put(ItemType.RadishSeed, new Texture("Foragings/Seeds/Radish_Seeds.png"));
        put(ItemType.MelonSeed, new Texture("Foragings/Seeds/Melon_Seeds.png"));
        put(ItemType.ParsnipSeed, new Texture("Foragings/Seeds/Parsnip_Seeds.png"));
        put(ItemType.PoppySeed, new Texture("Foragings/Seeds/Poppy_Seeds.png"));
        put(ItemType.FairySeed, new Texture("Foragings/Seeds/Fairy_Seeds.png"));
        put(ItemType.CranberrySeed, new Texture("Foragings/Seeds/Cranberry_Seeds.png"));
        put(ItemType.BeetSeed, new Texture("Foragings/Seeds/Beet_Seeds.png"));
        put(ItemType.AmaranthSeed, new Texture("Foragings/Seeds/Amaranth_Seeds.png"));
        put(ItemType.MahoganySeed, new Texture("Foragings/Seeds/Mahogany_Seed.png"));
        put(ItemType.YamSeed, new Texture("Foragings/Seeds/Yam_Seeds.png"));
        put(ItemType.TomatoSeed, new Texture("Foragings/Seeds/Tomato_Seeds.png"));
        put(ItemType.StarfruitSeed, new Texture("Foragings/Seeds/Starfruit_Seeds.png"));
        put(ItemType.PowdermelonSeed, new Texture("Foragings/Seeds/Powdermelon_Seeds.png"));
        put(ItemType.RareSeed, new Texture("Foragings/Seeds/Rare_Seed.png"));
        put(ItemType.PepperSeed, new Texture("Foragings/Seeds/Pepper_Seeds.png"));
        put(ItemType.JazzSeed, new Texture("Foragings/Seeds/Jazz_Seeds.png"));
        put(ItemType.GarlicSeed, new Texture("Foragings/Seeds/Garlic_Seeds.png"));
        put(ItemType.EggplantSeed, new Texture("Foragings/Seeds/Eggplant_Seeds.png"));
        put(ItemType.CarrotSeed, new Texture("Foragings/Seeds/Carrot_Seeds.png"));
        put(ItemType.BlueberrySeed, new Texture("Foragings/Seeds/Blueberry_Seeds.png"));
        put(ItemType.AncientSeed, new Texture("Foragings/Seeds/Ancient_Seed.png"));
        put(ItemType.TulipBulb, new Texture("Foragings/Seeds/Tulip_Bulb.png"));
        put(ItemType.AppleSapling, new Texture("Foragings/Seeds/Apple_Sapling.png"));
        put(ItemType.ApricotSapling, new Texture("Foragings/Seeds/Apricot_Sapling.png"));
        put(ItemType.Acorns, new Texture("Foragings/Seeds/Apricot_Sapling.png"));
        put(ItemType.BananaSapling, new Texture("Foragings/Seeds/Banana_Sapling.png"));
        put(ItemType.CherrySapling, new Texture("Foragings/Seeds/Cherry_Sapling.png"));
        put(ItemType.MangoSapling, new Texture("Foragings/Seeds/Mango_Sapling.png"));
        put(ItemType.OrangeSapling, new Texture("Foragings/Seeds/Orange_Sapling.png"));
        put(ItemType.PeachSapling, new Texture("Foragings/Seeds/Peach_Sapling.png"));
        put(ItemType.PomegranateSapling, new Texture("Foragings/Seeds/Pomegranate_Sapling.png"));
    }} ;

    private final static HashMap<ItemType, Texture[]> FORAGING_TREE_SPRITES = new HashMap<>(){{
        put(ItemType.MapleTree, new Texture[]{new Texture("Foragings/Trees/Maple_Stage_5.png"),
        new Texture("Foragings/Trees/Maple_stump_Spring.png")});
        put(ItemType.MahoganyTree, new Texture[]{new Texture("Foragings/Trees/Mahogany_Stage_5.png"),
            new Texture("Foragings/Trees/Mahogany_stump_Spring.png")} );
        put(ItemType.MushroomTree, new Texture[]{new Texture("Foragings/Trees/MushroomTree_Stage_5.png"),
            new Texture("Foragings/Trees/MushroomTree_Stage_5.png")});
        put(ItemType.PineTree,  new Texture[]{new Texture("Foragings/Trees/Pine_Stage_5.png"),
            new Texture("Foragings/Trees/Pine_stump_Spring.png")});
    }};

    private final static HashMap<ItemType, Texture[]> TREE_TEXTURES = new HashMap<>(){{
        put(ItemType.AppleTree, new Texture[]{
            new Texture("Foragings/Trees/AppleTreeLightning.png"), new Texture("Foragings/Trees/Apple_Sapling.png"),
            new Texture("Foragings/Trees/Apple_Stage_2.png"), new Texture("Foragings/Trees/Apple_Stage_4.png")
        , new Texture("Foragings/Trees/Apple_Stage_5.png"), new Texture("Foragings/Trees/Apple_Stage_5_Fruit.png")});
        put(ItemType.OrangeTree, new Texture[]{
            new Texture("Foragings/Trees/OrangeTreeLightning.png"), new Texture("Foragings/Trees/Orange_Sapling.png"),
            new Texture("Foragings/Trees/Orange_Stage_2.png"), new Texture("Foragings/Trees/Orange_Stage_4.png")
            , new Texture("Foragings/Trees/Orange_Stage_5.png"), new Texture("Foragings/Trees/Orange_Stage_5_Fruit.png")});
        put(ItemType.BananaTree, new Texture[]{
            new Texture("Foragings/Trees/BananaTreeLightning.png"), new Texture("Foragings/Trees/Banana_Sapling.png"),
            new Texture("Foragings/Trees/Banana_Stage_2.png"), new Texture("Foragings/Trees/Banana_Stage_4.png")
            , new Texture("Foragings/Trees/Banana_Stage_5.png"), new Texture("Foragings/Trees/Banana_Stage_5_Fruit.png")});
        put(ItemType.MangoTree, new Texture[]{
            new Texture("Foragings/Trees/MangoTreeLightning.png"), new Texture("Foragings/Trees/Mango_Sapling.png"),
            new Texture("Foragings/Trees/Mango_Stage_2.png"), new Texture("Foragings/Trees/Mango_Stage_4.png")
            , new Texture("Foragings/Trees/Mango_Stage_5.png"), new Texture("Foragings/Trees/Mango_Stage_5_Fruit.png")});
        put(ItemType.ApricotTree, new Texture[]{
            new Texture("Foragings/Trees/ApricotTreeLightning.png"), new Texture("Foragings/Trees/Apricot_Sapling.png"),
            new Texture("Foragings/Trees/Apricot_Stage_2.png"), new Texture("Foragings/Trees/Apricot_Stage_4.png")
            , new Texture("Foragings/Trees/Apricot_Stage_5.png"), new Texture("Foragings/Trees/Apricot_Stage_5_Fruit.png")});
        put(ItemType.PeachTree, new Texture[]{
            new Texture("Foragings/Trees/PeachTreeLightning.png"), new Texture("Foragings/Trees/Peach_Sapling.png"),
            new Texture("Foragings/Trees/Peach_Stage_2.png"), new Texture("Foragings/Trees/Peach_Stage_4.png")
            , new Texture("Foragings/Trees/Peach_Stage_5.png"), new Texture("Foragings/Trees/Peach_Stage_5_Fruit.png")});
        put(ItemType.MysticTree, new Texture[]{
            new Texture("Foragings/Trees/Mystic_Tree_Stump.png"), new Texture("Foragings/Trees/Mystic_Tree_Stage_1.png"),
            new Texture("Foragings/Trees/Mystic_Tree_Stage_2.png"), new Texture("Foragings/Trees/Mystic_Tree_Stage_3.png")
            , new Texture("Foragings/Trees/Mystic_Tree_Stage_4.png"), new Texture("Foragings/Trees/Mystic_Tree_Stage_5.png")});
        put(ItemType.PomegranateTree, new Texture[]{
            new Texture("Foragings/Trees/PomegranateTreeLightning.png"), new Texture("Foragings/Trees/Pomegranate_Sapling.png"),
            new Texture("Foragings/Trees/Pomegranate_Stage_2.png"), new Texture("Foragings/Trees/Pomegranate_Stage_4.png")
            , new Texture("Foragings/Trees/Pomegranate_Stage_5.png"), new Texture("Foragings/Trees/Pomegranate_Stage_5_Fruit.png")});
        put(ItemType.OakTree, new Texture[]{
            new Texture("Foragings/Trees/Oak_stump_Spring.png"), new Texture("Foragings/Trees/Oak_Stage_1.png"),
            new Texture("Foragings/Trees/Oak_Stage_2.png"), new Texture("Foragings/Trees/Oak_Stage_3.png")
            , new Texture("Foragings/Trees/Oak_Stage_4.png"), new Texture("Foragings/Trees/Oak_Stage_5.png")});
        put(ItemType.CherryTree, new Texture[]{
            new Texture("Foragings/Trees/CherryTreeLightning.png"), new Texture("Foragings/Trees/Cherry_Sapling.png"),
            new Texture("Foragings/Trees/Cherry_Stage_2.png"), new Texture("Foragings/Trees/Cherry_Stage_4.png")
            , new Texture("Foragings/Trees/Cherry_Stage_5.png"), new Texture("Foragings/Trees/Cherry_Stage_5_Fruit.png")});
    }};

    private static final HashMap<ItemType, Texture> MINERAL_SPRITES = new HashMap<>(){{
        put(ItemType.Amethyst, new Texture("Foragings/Minerals/Amethyst.png"));
        put(ItemType.Aquamarine, new Texture("Foragings/Minerals/Aquamarine.png"));
        put(ItemType.CopperOre, new Texture("Foragings/Minerals/Copper_Ore.png"));
        put(ItemType.Diamond, new Texture("Foragings/Minerals/Diamond.png"));
        put(ItemType.EarthCrystal, new Texture("Foragings/Minerals/Earth_Crystal.png"));
        put(ItemType.Emerald, new Texture("Foragings/Minerals/Emerald.png"));
        put(ItemType.Fiber, new Texture("Foragings/Minerals/Fiber.png"));
        put(ItemType.FireQuartz, new Texture("Foragings/Minerals/Fire_Quartz.png"));
        put(ItemType.FrozenTear, new Texture("Foragings/Minerals/Frozen_Tear.png"));
        put(ItemType.GoldOre, new Texture("Foragings/Minerals/Gold_Ore.png"));
        put(ItemType.IridiumOre, new Texture("Foragings/Minerals/Iridium_Ore.png"));
        put(ItemType.IronOre, new Texture("Foragings/Minerals/Iron_Ore.png"));
        put(ItemType.Jade, new Texture("Foragings/Minerals/Jade.png"));
        put(ItemType.PrismaticShard, new Texture("Foragings/Minerals/Prismatic_Shard.png"));
        put(ItemType.Quartz, new Texture("Foragings/Minerals/Quartz.png"));
        put(ItemType.Ruby, new Texture("Foragings/Minerals/Ruby.png"));
        put(ItemType.Stone, new Texture("Foragings/Minerals/Stone.png"));
        put(ItemType.Topaz, new Texture("Foragings/Minerals/Topaz.png"));
        put(ItemType.Wood, new Texture("Foragings/Minerals/Wood.png"));
    }};
    static {
        for(int i = 0; i<4; i++){
            for(int j = 0; j<4; j++){
                int k =j;
                if(j==3)
                    k =2;
                ALEX_TEXTURES[i][k] = new TextureRegion(ALEX, 22+j*16, 16+32*i, 16, 32);
            }
        }
    }

    private static TextureRegion[] generateTextureRegion(int x, int y, int w, int h){
        return new TextureRegion[]{
            new TextureRegion(BUILDINGS_IN_DIFFERENT_SEASONS[0], x, y, w, h),
            new TextureRegion(BUILDINGS_IN_DIFFERENT_SEASONS[1], x, y, w, h),
            new TextureRegion(BUILDINGS_IN_DIFFERENT_SEASONS[2], x, y, w, h),
            new TextureRegion(BUILDINGS_IN_DIFFERENT_SEASONS[3], x, y, w, h)
        };
    }

    public static TextureRegion[] getJojaMartSprites(){
        return JOJA_MART_SPRITES;
    }

    public static Texture getFullEnergySprite(){
        return FULL_ENERGY_SPRITE;
    }

    public static Texture getEmptyEnergyBarSprite(){
        return EMPTY_ENERGY_BAR_SPRITE;
    }

    public static TextureRegion[] getPierreSprites(){
        return PIERRE_SPRITES;
    }

    public static HashMap<ItemType, Texture[]> getTreeTextures(){
        return TREE_TEXTURES;
    }

    public static HashMap<ItemType, Texture> getSeedTextures(){
        return SEED_TEXTURES;
    }

    public static HashMap<ItemType, Texture> getMineralSprites(){
        return MINERAL_SPRITES;
    }

    public static Texture getGreenhouseSprite(){
        return GREENHOUSE_SPRITE;
    }

    public static TextureRegion[] getStardropSprites(){
        return STARDROP_SPRITES;
    }

    public static TextureRegion[] getFishStoreSprites(){
        return FISH_STORE_AND_HOUSE_SPRITES;
    }

    public static TextureRegion[] getBlackSmithSprites(){
        return BLACK_SMITH_SPRITES;
    }

    public static Texture getLakeTexture(){
        return LAKE_TEXTURE;
    }

    public static HashMap<ItemType, Texture[]> getForagingTreeSprites(){
        return FORAGING_TREE_SPRITES;
    }

    public static TextureRegion[] getCarpetnerSprites(){
        return CARPETNER_SPRITES;
    }

    public static TextureRegion[] getMarnieRanchSprites(){
        return MARNIE_RANCH_SPRITES;
    }

    public static Texture[] getInventorySprites(){
        return INVENTORY_SPRITES;
    }

    public static Texture[] getTilesTextures(){
        return TILES_TEXTURES;
    }
    public static TextureRegion[][] getAlexTextures(){
        return ALEX_TEXTURES;
    }
}
