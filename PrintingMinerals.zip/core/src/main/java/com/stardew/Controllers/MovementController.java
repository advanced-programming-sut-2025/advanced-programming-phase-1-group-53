package com.stardew.Controllers;

import com.badlogic.gdx.Input;
import com.stardew.Enums.TileKind;
import com.stardew.Models.Game.App;
import com.stardew.Models.Game.Game;

public class MovementController {
    private Game game;

    public Game getGame() {
        return game;
    }

    public void setGame(Game game) {
        this.game = game;
    }

    public boolean canPlayerMove(int direction){
        int x = 0;
        int y = 0;
        if(direction == 2) y = App.ADVANCE_OF_EACH_STEP;
        if(direction == 0) y = -App.ADVANCE_OF_EACH_STEP;
        if(direction == 1) x = App.ADVANCE_OF_EACH_STEP;
        if(direction == 3) x = -App.ADVANCE_OF_EACH_STEP;
        System.out.println(x+"kk"+y + App.getGame().dateAndTime.getDay()+ "rr" + App.getGame().dateAndTime.getHour());
        if(!App.getGame().getGameMap().areInBound(App.getCurrentPlayer().position.getX() + x,
            App.getCurrentPlayer().position.getY() + y))
            return false;
        System.out.println(App.getGame().getGameMap().getTileByPixelCoordinate(App.getCurrentPlayer().position.getX() + x,
            App.getCurrentPlayer().position.getY() + y).getTileKind());
        return App.getGame().getGameMap().getTileByPixelCoordinate(App.getCurrentPlayer().position.getX() + x,
            App.getCurrentPlayer().position.getY() + y).getTileKind().isWalkable();
    }

    public void movePlayer(int keyPressed){
        try {
            if (keyPressed == Input.Keys.W) {
                App.getCurrentPlayer().setDirection(2);
                App.getCurrentPlayer().setIdle(false);
            }
            if (keyPressed == Input.Keys.S) {
                App.getCurrentPlayer().setDirection(0);
                App.getCurrentPlayer().setIdle(false);
            }
            if (keyPressed == Input.Keys.A) {
                App.getCurrentPlayer().setDirection(3);
                App.getCurrentPlayer().setIdle(false);
            }
            if (keyPressed == Input.Keys.D) {
                App.getCurrentPlayer().setDirection(1);
                App.getCurrentPlayer().setIdle(false);
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    public void stopMoving(int keyPressed){
        App.getCurrentPlayer().setIdle(true);
    }
}
